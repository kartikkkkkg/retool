package project.user.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "subgroups")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sub_group_id")
    private Long subGroupId;
    private String name;
    @Column(name = "group_id")
    private Integer groupId;
}
