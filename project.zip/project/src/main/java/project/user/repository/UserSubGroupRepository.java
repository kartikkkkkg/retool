package project.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import project.user.model.UserSubGroup;

import java.util.List;

public interface UserSubGroupRepository extends JpaRepository<UserSubGroup, Long> {
    List<UserSubGroup> findByUserId(Long userId);
}
