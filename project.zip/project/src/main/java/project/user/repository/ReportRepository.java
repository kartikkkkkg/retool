package project.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import project.user.model.Report;

import java.util.List;
import java.util.Set;

public interface ReportRepository extends JpaRepository<Report, Integer> {
    List<Report> findBySubGroupIdIn(Set<Integer> subGroupIds);
    List<Report> findBySubGroupIdInAndNameContainingIgnoreCase(Set<Integer> subGroupIds, String name);
}
