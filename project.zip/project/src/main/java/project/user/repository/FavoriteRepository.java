package project.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import project.user.model.Favorite;

import java.util.List;
import java.util.Optional;

public interface FavoriteRepository extends JpaRepository<Favorite, Long> {
    List<Favorite> findByUserId(Long userId);
    Optional<Favorite> findByUserIdAndReportId(Long userId, Integer reportId);
}
