package project.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import project.user.model.SubGroup;

import java.util.List;
import java.util.Set;

public interface SubGroupRepository extends JpaRepository<SubGroup, Integer> {
    List<SubGroup> findAllBySubGroupIdIn(Set<Integer> subGroupIds);
}
