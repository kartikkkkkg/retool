package project.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.user.dto.DashboardResponse;
import project.user.model.Report;
import project.user.service.UserService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/dashboard/{userId}")
    public ResponseEntity<DashboardResponse> getDashboardData(@PathVariable Long userId) {
        Optional<DashboardResponse> dashboardData = userService.getDashboardData(userId);
        return dashboardData.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/reports/search")
    public ResponseEntity<List<Report>> searchReports(@RequestParam Long userId, @RequestParam String query) {
        List<Report> reports = userService.searchReports(userId, query);
        return ResponseEntity.ok(reports);
    }

    @PutMapping("/reports/favorite/{reportId}")
    public ResponseEntity<String> favoriteReport(@PathVariable Integer reportId, @RequestParam Long userId) {
        userService.favoriteReport(userId, reportId);
        return ResponseEntity.ok("Favorited report with ID: " + reportId);
    }

    @DeleteMapping("/reports/favorite/{reportId}")
    public ResponseEntity<String> unfavoriteReport(@PathVariable Integer reportId, @RequestParam Long userId) {
        userService.unfavoriteReport(userId, reportId);
        return ResponseEntity.ok("Unfavorited report with ID: " + reportId);
    }

    @GetMapping("/reports/{reportId}/download")
    public String downloadReport(@PathVariable Long reportId) {
        // This method will be implemented later
        return "Downloading report with ID: " + reportId;
    }
}
