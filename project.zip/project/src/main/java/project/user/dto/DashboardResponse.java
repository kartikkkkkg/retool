package project.user.dto;

import lombok.Data;
import project.user.model.Report;
import project.user.model.Favorite;
import project.user.model.SubGroup;

import java.util.List;

@Data
public class DashboardResponse {
    private List<Report> reports;
    private List<Favorite> favorites;
    private List<SubGroup> folders;
}
