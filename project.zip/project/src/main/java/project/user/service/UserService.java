package project.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import project.user.dto.DashboardResponse;
import project.user.model.Favorite;
import project.user.model.Report;
import project.user.model.SubGroup;
import project.user.model.UserSubGroup;
import project.user.repository.FavoriteRepository;
import project.user.repository.ReportRepository;
import project.user.repository.SubGroupRepository;
import project.user.repository.UserSubGroupRepository;
import project.user.repository.UserRepository;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final UserSubGroupRepository userSubGroupRepository;
    private final ReportRepository reportRepository;
    private final FavoriteRepository favoriteRepository;
    private final SubGroupRepository subGroupRepository;

    @Autowired
    public UserService(UserRepository userRepository, UserSubGroupRepository userSubGroupRepository, ReportRepository reportRepository, FavoriteRepository favoriteRepository, SubGroupRepository subGroupRepository) {
        this.userRepository = userRepository;
        this.userSubGroupRepository = userSubGroupRepository;
        this.reportRepository = reportRepository;
        this.favoriteRepository = favoriteRepository;
        this.subGroupRepository = subGroupRepository;
    }

    public Optional<DashboardResponse> getDashboardData(Long userId) {
        // Find the user to ensure they exist
        if (userRepository.findById(userId).isEmpty()) {
            return Optional.empty();
        }

        // 1. Get all subgroup IDs assigned to the normal user
        List<UserSubGroup> userSubGroups = userSubGroupRepository.findByUserId(userId);
        Set<Integer> subGroupIds = userSubGroups.stream()
                .map(UserSubGroup::getSubGroupId)
                .collect(Collectors.toSet());

        // 2. Find all reports for those subgroups
        List<Report> userReports = reportRepository.findBySubGroupIdIn(subGroupIds);

        // 3. Find all favorite reports for the user
        List<Favorite> userFavorites = favoriteRepository.findByUserId(userId);

        // 4. Find all subgroups (folders) for those subgroup IDs
        List<SubGroup> userFolders = subGroupRepository.findAllById(subGroupIds);

        // 5. Combine into a DashboardResponse DTO
        DashboardResponse response = new DashboardResponse();
        response.setReports(userReports);
        response.setFavorites(userFavorites);
        response.setFolders(userFolders);

        return Optional.of(response);
    }

    public List<Report> searchReports(Long userId, String query) {
        // 1. Get all subgroup IDs assigned to the normal user
        List<UserSubGroup> userSubGroups = userSubGroupRepository.findByUserId(userId);
        Set<Integer> subGroupIds = userSubGroups.stream()
                .map(UserSubGroup::getSubGroupId)
                .collect(Collectors.toSet());

        // 2. Find all reports for those subgroups that match the query
        return reportRepository.findBySubGroupIdInAndNameContainingIgnoreCase(subGroupIds, query);
    }

    public void favoriteReport(Long userId, Integer reportId) {
        // First, check if the report is already a favorite for this user to prevent duplicates
        if (favoriteRepository.findByUserIdAndReportId(userId, reportId).isEmpty()) {
            Favorite favorite = new Favorite();
            favorite.setUserId(userId);
            favorite.setReportId(reportId);
            favoriteRepository.save(favorite);
        }
    }

    public void unfavoriteReport(Long userId, Integer reportId) {
        Optional<Favorite> favorite = favoriteRepository.findByUserIdAndReportId(userId, reportId);
        favorite.ifPresent(favoriteRepository::delete);
    }
}
